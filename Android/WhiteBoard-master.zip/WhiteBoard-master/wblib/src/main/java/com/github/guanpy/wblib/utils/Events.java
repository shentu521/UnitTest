package com.github.guanpy.wblib.utils;

/**
 * @author gpy
 * @version 2015/8/26.
 */
public class Events {
	/**
	 * 白板相关
	 */
	public static final String WHITE_BOARD_UNDO_REDO = "undo_redo";

	public static final String WHITE_BOARD_TEXT_EDIT = "text_edit";
}