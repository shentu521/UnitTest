

项目简介：

该项目是基于Netty网络框架开发的电子白板，可实现同屏互动功能。同时该项目采用C/S模式，支持多人同时在线、并发实时同屏互动。
    
Netty是由JBOSS提供的一个java开源框架。Netty提供异步的、事件驱动的网络应用程序框架和工具，用以快速开发高性能、高可靠性的网络服务器和客户端程序。


特性说明：
1、可自定义画笔尺寸和颜色；
2、分享涂鸦
3、打开历史涂鸦
4、设置涂鸦为壁纸
5、自定义快捷键


注：服务端默认端口为8080；

如有问题，请发邮件至 13107635518@163.com

License

Copyright 2015-2019 yems

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.